This repository is for anyone who still use the BootstrapValidator.

__It's no longer supported.__

__Please upgrade to use [FormValidation](http://formvalidation.io).__
