package cc.shen0d.ui.main.pojo;

public class CloumnObj {
	private String id;
	private String title;
	private String operateFormatter;
	private String operateEvents;
	private String width;
	private String checkbox;
	private String type;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getOperateFormatter() {
		return operateFormatter;
	}

	public void setOperateFormatter(String operateFormatter) {
		this.operateFormatter = operateFormatter;
	}

	public String getOperateEvents() {
		return operateEvents;
	}

	public void setOperateEvents(String operateEvents) {
		this.operateEvents = operateEvents;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getCheckbox() {
		return checkbox;
	}

	public void setCheckbox(String checkbox) {
		this.checkbox = checkbox;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
