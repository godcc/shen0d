package cc.shen0d.web.controller;

/**
 * ������
 * 
 * @author sihan
 *
 */
public abstract class BaseController {

}
