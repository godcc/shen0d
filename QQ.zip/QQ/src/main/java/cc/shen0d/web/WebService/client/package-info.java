@javax.xml.bind.annotation.XmlSchema(namespace = "http://enpoint.WebService.web.shen0d.cc/")
package cc.shen0d.web.WebService.client;
