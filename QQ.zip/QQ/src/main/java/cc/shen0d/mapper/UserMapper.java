package cc.shen0d.mapper;

import cc.shen0d.pojo.entity.User;

public interface UserMapper extends BaseMapper<User> {
}
